﻿List<object> myList = new List<object>();

myList.Add(7);
myList.Add(28);
myList.Add(-1);
myList.Add(true);
myList.Add("chair");

foreach (object val in myList)
{
    Console.WriteLine("List item is "+ val);
    
}
var sum = 0;
foreach (int val in myList)
{   
    sum += val;
    Console.WriteLine("Sum item is "+ sum);
    
}


