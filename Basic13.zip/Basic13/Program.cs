﻿// // static string SayHello(string firstName = "buddy")
// // {
// //     return $"Hey {firstName}";
// // }
// // string greeting; //Specifies STRING as the RETURN TYPE
// // greeting = SayHello(); //stores the return as string greeting then prints it using  line 7
// // Console.WriteLine(greeting);

// //1) Print 1-255
// static void PrintNumbers()
// {
//     for(int i = 1; i <= 255; i++){
//     Console.WriteLine(i);
//     }
// }
// PrintNumbers();

// //2 Print Odd Numbs betwteen 1-255
// static void PrintOdds()
// {
//     for(int i = 1; i <= 255; i++){
//         if(i%2 != 0){
//         Console.WriteLine(i); }
//     }
// } 
// PrintOdds();

// //3 Print Sum
// static void PrintSum()
// {
//     int sum = 0;
//     // Print all of the numbers from 0 to 255, 
//     // but this time, also print the sum as you go. 
//     for(int i = 1; i <= 255; i++){
//         sum += i;
//         Console.WriteLine($"new number: {i} Sum: {sum}");
//     }
// }
// PrintSum();

// //4)Iterating through an Array

int[] numbers = new int[] {1,2,3,4,5,6,7};
// static void LoopArray(int[] numbers)
// {
//     // Write a function that would iterate through each item of the given integer array and 
//     // print each value to the console. 
//     for(int idx = 0; idx < numbers.Length; idx++){
//         Console.WriteLine($"array value is: +  {numbers[idx]}");
//     }
// }
// LoopArray(numbers);

// //5) Find Max

// int[] numbers1 = new int[] {1,2,3,4,5,6,7}; //same array as above just for visuals
// static int FindMax(int[] numbers1)
// {
//     int max = numbers1[0];
//     // Write a function that takes an integer array and prints and returns the maximum value in the array. 
//     // Your program should also work with a given array that has all negative numbers (e.g. [-3, -5, -7]), 
//     // or even a mix of positive numbers, negative numbers and zero.
//     for(int idx = 0; idx < numbers1.Length; idx++){
//         if (max < numbers1[idx]){
//             max = numbers1[idx];
//         }
//     }
//     Console.WriteLine($"max is {max}");
//     return max;
// }

// FindMax(numbers1);

// //6) Get Average

// static void GetAverage(int[] numbers)
// {   
//     int sum = 0;

//     // Write a function that takes an integer array and prints the AVERAGE of the values in the array.
//     // For example, with an array [2, 10, 3], your program should write 5 to the console.
//     for(int idx = 0; idx < numbers.Length; idx++){
//         sum += numbers[idx];
//     }
//     int avg = (sum/numbers.Length);
//     Console.WriteLine($"Average is {avg}");
// }

// GetAverage(numbers);


// //7) Array with Odd Numbers
// static int[] OddArray()
// {
//     int[] newArr = new int[256/2]; //255+1 for inclusivity 1-255 HALF ONLY because ODDS ONLY
//     for (int i = 1; i <=255; i +=2)
//     { //starting at 1, count by 2s until 255, every other num
//         newArr[i/2] = i;
//         Console.WriteLine(newArr[i/2]); //sets newArr index i , divide
//         Console.WriteLine($"i is {i}");
//     } 
//     Console.WriteLine($"newArr is {newArr}");
//     return newArr;
// }
// OddArray();

// 8) Greater than Y
// int[] numbers = new int[] {1,2,3,4,5,6,7};
// static int GreaterThanY(int[] numbers, int y)
// {
//     int num = 0;
//     for(int idx = 0; idx < numbers.Length; idx++){
//         if(numbers[idx] > y){
//         num += 1;
//         }
//     }
//     Console.WriteLine(num); 
//     return num;
// }

// GreaterThanY(numbers,2); //in numbers, there are 5 values greater than 2, {3,4,5,6,7}

//9) Square the Values
// int[] numbers = new int[] {1,2,3,4,5,6,7};
// static void SquareArrayValues(int[] numbers)
// {
//     for(int idx = 0; idx < numbers.Length; idx++)
//     {
//         numbers[idx] = numbers[idx] * numbers[idx];
//         Console.WriteLine(numbers[idx]);
//     }
//     Console.WriteLine($"numbers is equal to: {numbers}");
//     return;
// }
// SquareArrayValues(numbers);

//10) Eliminate Negs
// int[] numbers3 = new int[] {1,2,-3,4,-5,6,-4};
// static void EliminateNegatives(int[] numbers)
// {
//     for(int idx = 0; idx < numbers.Length; idx++)
// {
//     if (numbers[idx] < 0){
//         numbers[idx] = 0;
//         Console.WriteLine(numbers[idx]);
//     } Console.WriteLine(numbers);
// }
//     // Given an integer array "numbers", say [1, 5, 10, -2], create a function that replaces any negative number with the value of 0. 
//     // When the program is done, "numbers" should have no negative values, say [1, 5, 10, 0].
// }  

// EliminateNegatives(numbers3);

//11) Min,Max,Average
// static void MinMaxAverage(int[] numbers)
// {
// int sum1 = 0;
// int min = numbers[0];
// int max1 = numbers[0];
//     for(int idx = 0; idx < numbers.Length; idx++){
//         sum1 += numbers[idx];
//         Console.WriteLine($"sum is {sum1}");
//         if (max1 < numbers[idx])
//             max1 = numbers[idx];
//             Console.WriteLine($"max is {max1}");
//         if (min > numbers[idx])
//             min = numbers[idx];
//     }
//     int avg = sum1/numbers.Length;
//     Console.WriteLine(avg);
//     // Given an integer array, say [1, 5, 10, -2], create a function that prints the maximum number in the array, 
//     // the minimum value in the array, and the average of the values in the array.
// }
// MinMaxAverage(numbers);

//12)  Shifting the values in an Array

// static void ShiftValues(int[] numbers)
// {   
//     for (int idx = 0; idx < numbers.Length-1; idx++){
//         numbers[idx] = numbers[idx+1];
//         Console.WriteLine(numbers[idx]);
//     }
//     numbers[numbers.Length-1] = 0;
//     Console.WriteLine(numbers);
//     // Given an integer array, say [1, 5, 10, 7, -2], 
//     // Write a function that shifts each number by one to the front and adds '0' to the end. 
//     // For example, when the program is done, if the array [1, 5, 10, 7, -2] is passed to the function, 
//     // it should become [5, 10, 7, -2, 0].
// }

// ShiftValues(numbers);

// 13) Number to String 

static object[] NumToString(int[] numbers)
{
    object[] objects = new object[numbers.Length];
    for (int idx = 0; idx < numbers.Length-1; idx++){
        if (numbers[idx] < 0)
            objects[idx] = "Dojo";
        else 
            objects[idx] = numbers[1];
    } 
    return objects;
}

NumToString(numbers);