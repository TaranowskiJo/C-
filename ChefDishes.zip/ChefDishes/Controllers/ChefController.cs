using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using ChefDishes.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace ChefDishes.Controllers;

public class ChefController : Controller
{
    private ChefDishesContext _context; //_context is an object insance of the CrudContext class
    public ChefController(ChefDishesContext context)
    {
        _context = context;
    }

[HttpGet("/")]
public IActionResult Homepage()
{
    List<Chef> allChefs = _context.Chefs
    .Include(c => c.myDishes) /// how we will include our chefs dishes
    .ToList(); //essentially mydatabase.Dishes.ToList()
    
    return View("Home", allChefs);
}

[HttpGet("/add/chef")]
public ViewResult addChef()
{
    return View("CreateChef");
}

[HttpPost("/create/chef")]
public IActionResult createChef(Chef newChef)
    {
        if (ModelState.IsValid == false)
        {
            return addChef();
        }
        _context.Chefs.Add(newChef);
        _context.SaveChanges();
        return RedirectToAction("Homepage");
    }
}

