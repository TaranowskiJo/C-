using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using ChefDishes.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace ChefDishes.Controllers;

public class DishController : Controller
{
     private ChefDishesContext _context; //_context is an object insance of the CrudContext class
    public DishController(ChefDishesContext context)
    {
        _context = context;
    }

[HttpGet("/dishes/home")]
public IActionResult DishesHome()
{   
    //this is how we make dish creator show up in html
    List<Dish> allDishes = _context.Dishes
    .Include(dish => dish.Creator)
    //.ThenInclude wud b next step here
    .ToList(); //essentially mydatabase.Dishes.ToList()
    return View("DishesHome", allDishes );
}

[HttpGet("/add/dish")]
public ViewResult addDish()
{
    ViewBag.allChefs = _context.Chefs.ToList();
    return View("CreateDish");
}

[HttpPost("/create/dish")]
public IActionResult createDish (Dish newDish)
    {
        if (ModelState.IsValid == false)
        {
            return addDish();
        }
        _context.Dishes.Add(newDish);
        _context.SaveChanges();
        return RedirectToAction("DishesHome");
    }
}