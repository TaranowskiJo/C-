using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using ChefDishes.Models;
using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;

namespace ChefDishes.Models;

public class LegalAgeValidation : ValidationAttribute
{
    public override string FormatErrorMessage(string name)
    {
        return " must be 18 or older";
    }

    protected override ValidationResult? IsValid(object? value, ValidationContext validationContext)
    {
        var BirthDate = value as DateTime? ?? new DateTime();

        DateTime dob = (DateTime)BirthDate;
        var dateNow = DateTime.Now;
        var age = dateNow.Year - dob.Year;
        
        if(age < 18)
        {
            return new ValidationResult(FormatErrorMessage(validationContext.DisplayName));
        } 
    return ValidationResult.Success;
    } 
}