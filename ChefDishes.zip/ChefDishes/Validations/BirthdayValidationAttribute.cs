using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using ChefDishes.Models;
using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;

namespace ChefDishes.Models;

public class BirthdayValidation : ValidationAttribute
{
    public override string FormatErrorMessage(string name)
    {
        return " should not be a future date";
    }

    protected override ValidationResult? IsValid(object? value, ValidationContext validationContext)
    {
        var BirthDate = value as DateTime? ?? new DateTime();

        if (BirthDate.Date > DateTime.Today)
        {
            return new ValidationResult(FormatErrorMessage(validationContext.DisplayName));
        } 
    return ValidationResult.Success;
    } 
}