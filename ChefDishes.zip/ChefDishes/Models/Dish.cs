#pragma warning disable CS8618
using System.ComponentModel.DataAnnotations;
namespace ChefDishes.Models;
public class Dish
{
    [Key]

    public int DishId { get; set; }

    [Required]
    [MinLength(2, ErrorMessage = "Must be at least 2 characters")]
    public string Name { get; set; } 

    
    public int Calories { get; set; }
    public int Tastines { get; set; }

    [Required]
    [MinLength(5, ErrorMessage = "Must leave at least 5 characters in description")]
    public string Description { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.Now;
    public DateTime UpdatedAt { get; set; } = DateTime.Now;
    

//one to many relationships
// relationship properties below
//must have foreign keys that match with id syntax
//MUS use .Include for nav prop data to be included v ia a SQL JOIN statement
public int ChefId { get; set; }
public Chef? Creator { get; set; } //1 creator related to each dish

}