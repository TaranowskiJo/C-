#pragma warning disable CS8618
using System.ComponentModel.DataAnnotations;
namespace ChefDishes.Models;
public class Chef
{
    [Key]

    public int ChefId { get; set; }

    [Required]
    [Display(Name ="First Name")]
    [MinLength(2, ErrorMessage = "Must be at least 2 characters")]
    public string FirstName { get; set; } 

    [Required]
    [Display(Name ="Last Name")]
    [MinLength(2, ErrorMessage = "Must be at least 2 characters")]
    public string LastName { get; set; } 

    [Required]
    [BirthdayValidation]
    [LegalAgeValidation]
    [Display(Name ="Date of Birth")]
    [DataType(DataType.Date)]
    public DateTime? BirthDate { get; set; }

    

    public DateTime CreatedAt { get; set; } = DateTime.Now;
    public DateTime UpdatedAt { get; set; } = DateTime.Now;

    
    //nav prop list of dishes
    public List<Dish> myDishes {get; set;} = new List<Dish>();
    
    
    
    public string FullName()
    {
        return FirstName + " " + LastName;
    }

    public int Age()
    {   
        if ( BirthDate != null){
        DateTime dob = (DateTime)BirthDate;
        var dateNow = DateTime.Now;
        var age = dateNow.Year - dob.Year;
        return age;
        } else {
            return 0;
        }
    }
    

}
