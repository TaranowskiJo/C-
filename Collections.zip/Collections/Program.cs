﻿

//THREE BASIC ARRAYS
int[] arr = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};

string[] myArr = new string[]
{
    "Joseph",
    "Patrick",
    "Nelly",
    "Brock",
    "Pikachu"
};

Console.WriteLine(arr[4]);
Console.WriteLine(myArr[2]);

bool[] alternate = new bool[]
{
    true,
    false,
    true,
    false,
    true,
    false,
    true,
    false,
    true,
    false,
};
Console.WriteLine(alternate[3]);


//LIST OF FLAVORS
List<string> flavors = new List<string>() {
    "cherry garcia",
    "mint chocolate chip",
    "chocolate",
    "chocolate chip",
    "lobster"
};

Console.WriteLine(flavors.Count);
Console.WriteLine(flavors[2]);

flavors.RemoveAt(2);
Console.WriteLine(flavors.Count);


//USER INFO DICTIONARY
Dictionary<string, string> someDictionary = new Dictionary<string, string>() {
    {"Joseph", "Chocolate Chip"},
    {"Patrick", "Cherry Garcia"},
    {"Nelly", "Lobster"}
};

foreach (KeyValuePair<string,string> entry in someDictionary)
{
    Console.WriteLine(entry.Key + "-" + entry.Value);
}