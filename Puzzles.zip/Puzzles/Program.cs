﻿static void RandomArray(){
    int sum = 0;
    Random rand = new Random();
    int[] numArray = new int[10];
    for(int i = 0; i < numArray.Length; i++){
        numArray[i] =  rand.Next(5,25);
        Console.WriteLine(numArray[i]);
        sum += numArray[i];
    }
        Console.WriteLine($"sum is {sum}");
}
RandomArray();


static double TossCoin(int num)
{
    double heads = 0;
    Random rand = new Random();
    Console.WriteLine("Tossing a Coin!");
    for (int i = 1; i <= num; i++)
    {
        int toss = rand.Next(0,2);
        if (toss == 0){
            Console.WriteLine("Tails");
        }
        else 
        {
            Console.WriteLine("Heads");
            heads++;
            Console.WriteLine($"heads is {heads}");
        }
    }
    double ratio = (double) heads/num;
    // double DoubleValue = ratio;
    Console.WriteLine(ratio);
    return ratio;
}
double CResult = TossCoin(5);
Console.WriteLine(CResult);


// static void Names(){
//     Random rand = new Random();
//     List<string> names = new List<string>() {
//         "Todd",
//         "Tiffany",
//         "Charlie",
//         "Geneva",
//         "Sydney"
//     };
//     for(int i = 0; i < names.Count; i++){
//         if(names[i].Length < 5)
//             // Console.WriteLine($"{names[i]} is being removed");
//             names.Remove(names[i]);
//     Console.WriteLine(names[i]);
//     }
//     return;
    

// }
// Names();