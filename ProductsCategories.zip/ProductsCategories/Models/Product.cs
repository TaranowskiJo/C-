#pragma warning disable CS8618
using System.ComponentModel.DataAnnotations;
namespace ProductsCategories.Models;
public class Product
{
    [Key]

    public int ProductId { get; set; }

    [Required]
    [MinLength(2, ErrorMessage = "Must be at least 2 characters")]
    public string Name { get; set; } 

    [Required]
    [MinLength(5, ErrorMessage = "Must be at least 5 characters")]
    public string Description { get; set; } 

    [Required]
    [Display(Name = "Price")]
    public decimal Price { get; set; } //use double not decimal

    public DateTime CreatedAt { get; set; } = DateTime.Now;
    public DateTime UpdatedAt { get; set; } = DateTime.Now;

    public List<Association> Items { get; set; } = new List<Association>(); //matches context.cs

    
}