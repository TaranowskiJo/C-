#pragma warning disable CS8618
using System.ComponentModel.DataAnnotations;
namespace ProductsCategories.Models;
public class Association
{
    [Key]

    public int ProductsCategoryId {get; set;} //better as association id

    public DateTime CreatedAt { get; set; } = DateTime.Now;
    public DateTime UpdatedAt { get; set; } = DateTime.Now;


    // relationship properties below//
    //aka Navigation properties
    //functionally a join table
    
    public int ProductId { get; set; }
    public Product? Product { get; set; } //adds in the product object is nullable because is might not always exist 
    public int CategoryId { get; set; }
    public Category? Category { get; set; } //adds in the category object
}