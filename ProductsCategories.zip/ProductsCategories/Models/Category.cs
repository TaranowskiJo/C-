#pragma warning disable CS8618
using System.ComponentModel.DataAnnotations;
namespace ProductsCategories.Models;
public class Category
{
    [Key]

    public int CategoryId { get; set; }

    [Required]
    [MinLength(2, ErrorMessage = "Must be at least 2 characters")]
    public string Name { get; set; } 

    public DateTime CreatedAt { get; set; } = DateTime.Now;
    public DateTime UpdatedAt { get; set; } = DateTime.Now;
    

//one to many relationships
// relationship properties below
//must have foreign keys that match with id syntax
//MUS use .Include for nav prop data to be included v ia a SQL JOIN statement

///these are examples for one to many, they are nonlist properties
///////public int ProductId { get; set; }
///////public Product? Product { get; set; } //1 creator related to each dish
///end one to many


public List<Association> Items { get; set; } = new List<Association>(); //matches context.cs
//not nullable list because we still want to be able to interact with it when empty

}