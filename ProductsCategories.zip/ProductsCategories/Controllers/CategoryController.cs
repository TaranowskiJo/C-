using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using ProductsCategories.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace ProductsCategories.Controllers;

public class CategoryController : Controller
{
    private ProductsCategoriesContext _context; //_context is an object insance of the CrudContext class
    public CategoryController(ProductsCategoriesContext context)
    {
        _context = context;
    }



    [HttpGet("/")]
    public IActionResult Homepage()
    {
        ViewBag.allCategories = _context.Categories;
        // .Include(c => c.myDishes) /// how we will include our chefs dishes
         //essentially mydatabase.Dishes.ToList()
        
        return View("Category");
    }

    [HttpGet("/Category/{CategoryId}")]
    public IActionResult aCategory(int CategoryId)
    {
        Category? aCategory = _context.Categories.FirstOrDefault(category => category.CategoryId == CategoryId);

        if (aCategory == null)
        {
            return RedirectToAction("Homepage");
        }
        Console.WriteLine(aCategory.CategoryId);

         var currentProducts = _context.Products
            .Include(p => p.Items)
            .Where(c => c.Items.Any(c => c.CategoryId == CategoryId));
        ViewBag.currentProducts = currentProducts; 
        var excludedIDs = new HashSet<int>(currentProducts.Select(p => p.ProductId)); 
        var result = _context.Products.Include(p=>p.Items).Where(c => !excludedIDs.Contains(c.ProductId)); 
        ViewBag.allProducts = result;        
        ViewBag.aCategory = aCategory; //comes from line 32
        // .Include(c => c.myDishes) /// how we will include our chefs dishes
        //essentially mydatabase.Dishes.ToList()
        
        return View("aCategory");
    }

    [HttpPost("/create/Category")]
    public IActionResult createCategory(Category newCategory)
    {
        if (ModelState.IsValid == false)
        {
            return Homepage();
        }
        _context.Categories.Add(newCategory);
        _context.SaveChanges();
        return RedirectToAction("Homepage");
    }
}