using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using ProductsCategories.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace ProductsCategories.Controllers;

public class ProductController : Controller
{
    private ProductsCategoriesContext _context; //_context is an object insance of the CrudContext class
    public ProductController(ProductsCategoriesContext context)
    {
        _context = context;
    }



    [HttpGet("/Products")]
    public IActionResult ProductHome()
    {
        ViewBag.allProducts = _context.Products;
        // .Include(c => c.myDishes) /// how we will include our chefs dishes
        //essentially mydatabase.Dishes.ToList()
        
        return View("Product");
    }

    [HttpGet("/product/{ProductId}")]
    public IActionResult aProduct(int ProductId)
    {
        Product? aProduct = _context.Products.FirstOrDefault(product => product.ProductId == ProductId);

        if (aProduct == null)
        {
            return RedirectToAction("ProductHome");
        }
        Console.WriteLine(aProduct.ProductId);

        var currentCategories = _context.Categories
            .Include(c => c.Items)
            .Where(p => p.Items.Any(p => p.ProductId == ProductId));
        ViewBag.currentCategories = currentCategories;

        var excludedIDs = new HashSet<int>(currentCategories.Select(c => c.CategoryId)); 
        var result = _context.Categories.Include(c=>c.Items).Where(p => !excludedIDs.Contains(p.CategoryId)); 
        ViewBag.allCategories = result;
        ViewBag.aProduct = aProduct; //comes from line 32
        // .Include(c => c.myDishes) /// how we will include our chefs dishes
        //essentially mydatabase.Dishes.ToList()
        
        return View("aProduct");
    }

    [HttpPost("/create/Product")]
    public IActionResult createProduct(Product newProduct)
    {
        if (ModelState.IsValid == false)
        {
            return ProductHome();
        }
    _context.Products.Add(newProduct);
    _context.SaveChanges();
    return RedirectToAction("ProductHome");
    }

    [HttpPost("/add/{ProductId}/Category")]
    public IActionResult addCategory(int ProductId, Association newAssociation)
    {

        if (ModelState.IsValid == false)
        {
            return ProductHome();
        }

        newAssociation.ProductId = ProductId;
        _context.Associations.Add(newAssociation);   
        Product? product = _context.Products.FirstOrDefault(p => p.ProductId == ProductId);
        Category? aCategory = _context.Categories.FirstOrDefault(c => c.CategoryId == newAssociation.CategoryId);
        product.Items.Add(newAssociation);
        aCategory.Items.Add(newAssociation);
        _context.SaveChanges();
        return aProduct(ProductId);
     //comes from line 32

    } 

}